# HardwareVergleich46

## Build Container

docker build -t hardwarevergleich46-node .

## Start Container

docker run -d -p 8080:8080 hardwarevergleich46-node

## Adresse

http://localhost:8080/
